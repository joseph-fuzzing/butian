#!/usr/bin/env python
#coding=utf-8
#use:调用实例ID执行命令

from aliyunsdkcore.client import AcsClient
from aliyunsdkcore.acs_exception.exceptions import ClientException
from aliyunsdkcore.acs_exception.exceptions import ServerException
from aliyunsdkecs.request.v20140526.InvokeCommandRequest import InvokeCommandRequest

client = AcsClient('111', '111', 'ap-southeast-1')

request = InvokeCommandRequest()
request.set_accept_format('json')

request.set_CommandId("c-sgp12ai9p7c79j4")
request.set_InstanceIds(["i-t4nc0tyj9tfk37qffznw"])

response = client.do_action_with_exception(request)
# python2:  print(response) 
print(str(response, encoding='utf-8'))
