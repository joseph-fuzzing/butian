#!/usr/bin/env python
#coding=utf-8
#use:获取实例ID

from aliyunsdkcore.client import AcsClient
from aliyunsdkcore.acs_exception.exceptions import ClientException
from aliyunsdkcore.acs_exception.exceptions import ServerException
from aliyunsdkecs.request.v20140526.DescribeInstancesRequest import DescribeInstancesRequest
Region=["cn-qingdao","cn-beijing","cn-zhangjiakou","cn-huhehaote","cn-wulanchabu","cn-hangzhou","cn-shanghai","cn-shenzhen","cn-heyuan","cn-chengdu","cn-hongkong","ap-southeast-1","ap-southeast-2","ap-southeast-3","ap-southeast-5","ap-south-1","ap-northeast-1","us-west-1","us-east-1","eu-central-1","eu-west-1","me-east-1"]
for Region_id in Region:
	client = AcsClient('key', '11', Region_id)
	request = DescribeInstancesRequest()
	request.set_accept_format('json')
	response = client.do_action_with_exception(request)
	print(str(response, encoding='utf-8'))
	pass