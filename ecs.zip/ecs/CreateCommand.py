#!/usr/bin/env python
#coding=utf-8
#use:创建执行命令实例ID

from aliyunsdkcore.client import AcsClient
from aliyunsdkcore.acs_exception.exceptions import ClientException
from aliyunsdkcore.acs_exception.exceptions import ServerException
from aliyunsdkecs.request.v20140526.CreateCommandRequest import CreateCommandRequest
client = AcsClient('key', '111', 'ap-southeast-1')

request = CreateCommandRequest()
request.set_accept_format('json')

request.set_Name("test1")
#Windows实例适用的Bat脚本（RunBatScript）
#Windows实例适用的PowerShell脚本（RunPowerShellScript）
#CommandContent该参数的值必须使用Base64编码后传输
request.set_Type("RunShellScript")
request.set_CommandContent("Y3VybCB2eG1jZHguZG5zbG9nLmNu")
response = client.do_action_with_exception(request)
# python2: print(response)
print(str(response, encoding='utf-8'))